#include "bad_length.h"


const char* bad_length::what() const noexcept {
	return "providing incorrect length";
}