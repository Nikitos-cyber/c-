#include "IntegerArray.h"


IntegerArray::IntegerArray(int length) {

	if (length > 0) {
		data = new int[length];
	}
	else if (length < 0) {
		throw bad_length();
	}

}

void IntegerArray::copy(const IntegerArray& copy_arr) {
	if (data != nullptr)
		delete data;

	data = new int[copy_arr.length];

	for (int i = 0; i < copy_arr.length; i++) {
		data[i] = copy_arr.data[i];
	}

	length = copy_arr.length;
}


IntegerArray::IntegerArray(const IntegerArray& copy_arr) {
	copy(copy_arr);
}

void IntegerArray::add(int value) {

	int* newData = new int[length + 1];
	for (int i = 0; i < length; i++) {
		newData[i] = data[i];
	}
	delete data;
	newData[length] = value;
	length++;
	data = newData;
}

void IntegerArray::show() {
	for (int i = 0; i < length; i++) {
		cout << data[i] << " ";
	}
	cout << endl;
}

int& IntegerArray::operator[](int i) {
	if (i < 0 || i >= length) {
		throw bad_range();
	}
	return data[i];
}

void IntegerArray::resize(int size) {

	if (length == size) {
		return;
	}
	else if (size <= 0) {
		delete data;
		length = 0;
		return;
	}

	if (size < 0) {
		throw bad_length();
	}
	int* newArr = new int[size];

	if (size >= length) {

		for (int i = 0; i < length; i++) {
			newArr[i] = data[i];
		}
		length = size;
	}
	else if (size < length) {

		for (int i = 0; i < size; i++) {
			newArr[i] = data[i];
		}

		length = size;

	}

	delete data;
	data = newArr;

}

void IntegerArray::insert(int value, int index) {
	if (index < 0 || index > length - 1) {
		throw bad_range();
	}

	int* newArr = new int[length + 1];
	int i = 0;
	for (; i < index; i++) {
		newArr[i] = data[i];
	}

	newArr[index] = value;

	for (; i < length; i++) {
		newArr[i + 1] = data[i];
	}

	delete data;
	data = newArr;
}

void IntegerArray::addBefore(int value) {
	insert(value, 0);
}

void IntegerArray::addEnd(int value) {
	if (length == 0)
		addBefore(value);
	else
		insert(value, length - 1);
}

void IntegerArray::remove(int index) {
	if (index < 0 || index > length - 1) {
		throw bad_range();
	}
	if (length < 1) {
		return;
	}

	int* newArr = new int[length - 1];

	int i = 0;
	for (; i < index; i++) {
		newArr[i] = data[i];
	}

	for (; i < length - 1; i++) {
		newArr[i] = data[i + 1];
	}

	length--;
	delete data;
	data = newArr;
}

int IntegerArray::find(int value) {

	for (int i = 0; i < length; i++) {
		if (value == data[i]) {
			return i;
		}
	}
	return -1;
}

IntegerArray::~IntegerArray() {
	delete[] data;
}