#pragma once

#include <iostream>
using namespace std;

class bad_length : public exception {
public:
	const char* what() const noexcept override;
};