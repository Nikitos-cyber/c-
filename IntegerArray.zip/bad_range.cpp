#include "bad_range.h"

const char* bad_range::what() const noexcept {
	return "array out of bounds";
}