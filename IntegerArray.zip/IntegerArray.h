#pragma once
#include "bad_length.h"
#include "bad_range.h"

class IntegerArray {
	int length;
	int* data = nullptr;
public:
	IntegerArray(int);
	IntegerArray(const IntegerArray&);
	void add(int);
	void addBefore(int);
	void addEnd(int);
	void show();
	int& operator [](int);
	void resize(int);
	void copy(const IntegerArray&);
	void copy(const IntegerArray&, int);
	void insert(int, int);
	void remove(int);
	int find(int);
	~IntegerArray();
};