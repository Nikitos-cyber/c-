﻿#include <iostream>

using namespace std;


#include "IntegerArray.h"

int main()
{
	try {
		IntegerArray arr(10);
		arr.add(12);
		arr.add(19);
		IntegerArray arr2(arr);
		arr2.resize(2);
		arr2.addBefore(-1);
		arr2.addEnd(-2);
		arr2.remove(0);
		arr2.show();
		cout << endl << arr2.find(-2) << endl;
		cout << endl << arr2[0] << endl;
	}
	catch (const bad_length& bl) {
		cout << bl.what() << endl;
	}
	catch (const bad_range& br) {
		cout << br.what() << endl;
	}
	catch (const bad_alloc& ba) {
		cout << ba.what() << endl;
	}


	return 0;
}


